# Getting started 

This video is a bit outdated since it was made using the previous version, but the concepts are the same as what we do now. You can watch the video [here](https://www.youtube.com/watch?v=sYjgDIgD7AY) or use the new and improved guide [here](./BeginnersGuideStepByStep.md)
